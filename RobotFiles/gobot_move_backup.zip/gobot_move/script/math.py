import math
import time

f1=-4e-05
f2=-9e-05

s = "f1 is %f,f2 is %f, %f"%(f1,f2,math.pi)
print s

x = 2.2
y = 2

print math.pow(x,y)

z = math.pow(x,y)
print math.sqrt(z)
