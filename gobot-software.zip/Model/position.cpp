#include "position.h"

Position::Position(): x(0), y(0) {}

Position::Position(const double _x, const double _y): x(_x), y(_y) {}
