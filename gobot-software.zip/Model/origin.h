#ifndef ORIGIN_H
#define ORIGIN_H

enum Origin { POINTS, GROUPS, MAP };

#endif // ORIGIN_H
